const Course = require("../model/courseEventModel.js");
const Student = require("../model/studentModel.js");

exports.checkEnrollmentEligibility = async (req, res) => {
  try {
    const { studentId, courseId } = req.body;
    console.log("✅ Route hit! Body:", req.body);

    // Fetch course and student
    const course = await Course.findById(courseId);
    const student = await Student.findById(studentId);

    if (!course || !student) {
      return res.status(404).json({
        success: false,
        message: "Student or Course not found",
      });
    }

    const prerequisites = course.prerequisites || {};
    const { postGraduationRequired, postGraduationYearRange } = prerequisites;

    // 🔍 If post-graduation is required
    if (postGraduationRequired === "yes") {
      const degrees = student.postGraduationDegrees || [];

      const isEligible = degrees.some((deg) => {
        if (!deg || deg.isCompleted !== true || !deg.yearOfGraduation) {
          return false;
        }

        if (postGraduationYearRange?.start && postGraduationYearRange?.end) {
          const year = parseInt(deg.yearOfGraduation);
          return (
            year >= parseInt(postGraduationYearRange.start) &&
            year <= parseInt(postGraduationYearRange.end)
          );
        }

        return true; // No year range specified, any completed post-grad is fine
      });

      if (!isEligible) {
        return res.status(403).json({
          success: false,
          message: `You must have completed a post-graduation${
            postGraduationYearRange?.start && postGraduationYearRange?.end
              ? ` between ${postGraduationYearRange.start} and ${postGraduationYearRange.end}`
              : ""
          } to register for this course.`,
        });
      }
    }

    // ✅ Eligible
    return res.status(200).json({
      success: true,
      message: "You are eligible to enroll in this course.",
    });
  } catch (error) {
    console.error("Eligibility check failed:", error);
    res.status(500).json({
      success: false,
      message: "Server error during eligibility check",
    });
  }
};
