const Student = require("../model/studentModel.js");
const dotenv = require("dotenv");
const cloudinary = require("cloudinary").v2;
const mongoose = require("mongoose");
const CourseSetup = require("../model/courseSetupModel.js");
dotenv.config();

const { CLOUD_NAME, API_KEY, API_SECRET } = process.env;

if (!CLOUD_NAME || !API_KEY || !API_SECRET) {
  throw new Error(
    "Cloudinary configuration is missing. Check your environment variables."
  );
}

// ********************************************** The Cloudinary upload function start here ********************************************** //

cloudinary.config({
  cloud_name: CLOUD_NAME,
  api_key: API_KEY,
  api_secret: API_SECRET,
});

const uploadImageToCloudinary = async (imageBuffer) => {
  return new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
      {
        folder: "aoa-bd/student-profile", // Specify the folder name here
      },
      (error, result) => {
        if (error) {
          reject(error);
        } else {
          resolve({
            url: result.secure_url,
            public_id: result.public_id,
          });
        }
      }
    );
    stream.end(imageBuffer);
  });
};

// ********************************************** Upload PDF to Cloudinary ********************************************** //

const uploadPdfToCloudinary = async (pdfBuffer, studentName, bmdcNo) => {
  return new Promise((resolve, reject) => {
    const sanitizedStudentName = studentName.replace(/\s+/g, "_"); // Replace spaces with underscores
    const timestamp = Date.now(); // Unique timestamp
    const uniqueFilename = `document_${timestamp}`; // Ensuring unique file name

    // Convert bmdcNo to string if it's a number
    const sanitizedBdmcNo = String(bmdcNo).replace(/\s+/g, "_");

    const folderPath = `aoa-bd/documents/${sanitizedStudentName}_${sanitizedBdmcNo}`;

    const stream = cloudinary.uploader.upload_stream(
      { folder: folderPath, public_id: uniqueFilename, resource_type: "raw" }, // Set unique file name
      (error, result) => {
        if (error) reject(error);
        else resolve({ url: result.secure_url, public_id: result.public_id });
      }
    );
    stream.end(pdfBuffer);
  });
};

const deletePdfFromCloudinary = async (publicId) => {
  return new Promise((resolve, reject) => {
    cloudinary.uploader.destroy(
      publicId,
      { resource_type: "raw" },
      (error, result) => {
        if (error) {
          reject(error); // Reject the promise if an error occurs
        } else {
          resolve(result); // Resolve with the result if successful
        }
      }
    );
  });
};

// ********************************************** The Cloudinary upload function end here ********************************************** //

// ********************************************** Get Profile Data function start here ********************************************** //

const getProfileData = async (req, res) => {
  try {
    // Get the user ID from the verified JWT token
    const userId = req.user._id;

    // Fetch the user's profile using the ID
    const userProfile = await Student.findById(userId);

    if (!userProfile) {
      return res.status(404).json({ message: "User profile not found" });
    }

    // Return the user profile data
    res.json(userProfile);
  } catch (err) {
    res
      .status(500)
      .json({ message: "Error fetching profile data", error: err.message });
  }
};

// ********************************************** Get Profile Data function start here ********************************************** //

const getStudentProfileByAdmin = async (req, res) => {
  try {
    // Extract studentId from the request parameters
    const { studentId } = req.params;

    // Fetch the student's profile using the ID
    const studentProfile = await Student.findById(studentId);

    if (!studentProfile) {
      return res.status(404).json({ message: "Student profile not found" });
    }

    // Return the student profile data
    res.json(studentProfile);
  } catch (err) {
    console.error("Error fetching student profile:", err);
    res
      .status(500)
      .json({ message: "Error fetching student profile", error: err.message });
  }
};

// ********************************************** Get Profile Data function end here ********************************************** //

// ********************************************** Update Profile Photo function start here ********************************************** //

const updateProfileImage = async (req, res) => {
  try {
    // Get the user ID from the verified JWT token
    const userId = req.user._id;

    // Get the uploaded file from the request
    const profileImage = req.file;

    // Find the student profile
    const studentProfile = await Student.findById(userId);
    if (!studentProfile) {
      return res.status(404).json({ error: "User profile not found" });
    }

    // If user already has a profile image, delete it from Cloudinary
    if (studentProfile.picture.length > 0) {
      const oldImage = studentProfile.picture[0]; // Get the first (only) image
      if (oldImage.public_id) {
        try {
          await cloudinary.uploader.destroy(oldImage.public_id); // Delete from Cloudinary
          console.log("Old image deleted:", oldImage.public_id);
        } catch (err) {
          console.error("Error deleting old image from Cloudinary:", err);
        }
      }
    }

    // Upload the new image to Cloudinary
    let uploadedImage;
    try {
      uploadedImage = await uploadImageToCloudinary(profileImage.buffer);
    } catch (err) {
      console.error("Error uploading image to Cloudinary:", err);
      return res.status(500).json({ error: "Failed to upload profile image" });
    }

    // Replace the old picture with the new one (ensure it's an array)
    studentProfile.picture = [
      {
        url: uploadedImage.url,
        public_id: uploadedImage.public_id,
      },
    ];

    // Save the updated profile
    await studentProfile.save();

    // Respond with the updated profile
    res.status(200).json(studentProfile);
  } catch (err) {
    console.error("Error updating profile image:", err);
    res
      .status(500)
      .json({ message: "Error updating profile image", error: err.message });
  }
};

// ********************************************** Update Profile Photo function start here ********************************************** //

// ********************************************** Upload PDF & Update Status ********************************************** /

const updateCourseDocument = async (req, res) => {
  const userId = req.user._id;
  const { courseId, status, removedFiles, completionYear } = req.body;
  const pdfFiles = req.files;

  try {
    if (!courseId || !mongoose.Types.ObjectId.isValid(courseId)) {
      return res.status(400).json({ message: "Invalid or missing course ID." });
    }

    const studentProfile = await Student.findById(userId);
    if (!studentProfile) {
      return res.status(404).json({ message: "Student profile not found." });
    }

    const courseData = await CourseSetup.findById(courseId);
    if (!courseData) {
      return res.status(404).json({ message: "Course not found." });
    }

    const allowMultiple = courseData.typeOfParticipation === 1;

    // Check if course already exists in profile
    const existingCourseIndex = studentProfile.courses.findIndex(
      (c) => c._id.toString() === courseId
    );
    const existingCourse = studentProfile.courses[existingCourseIndex];

    if (status === "no") {
      // ✅ Delete existing documents from Cloudinary
      if (existingCourse?.documents?.length) {
        for (const doc of existingCourse.documents) {
          await deletePdfFromCloudinary(doc.public_id);
        }
      }

      // ✅ Prepare updated course object with 'no' status
      const updatedCourse = {
        _id: courseId,
        status: "no",
        completionYear: "Not yet",
        documents: [],
      };

      if (existingCourseIndex > -1) {
        studentProfile.courses[existingCourseIndex] = updatedCourse;
      } else {
        studentProfile.courses.push(updatedCourse);
      }

      await studentProfile.save();

      return res.status(200).json({
        message: "Course status set to 'no'. Documents deleted.",
        studentProfile,
      });
    }

    // If status is 'yes'
    if (status === "yes") {
      if (!completionYear) {
        return res
          .status(400)
          .json({ message: "Completion year is required." });
      }

      // Retain only documents that were not removed
      const remainingDocs =
        existingCourse?.documents?.filter(
          (doc) => !removedFiles?.includes(doc.public_id)
        ) || [];

      // Check if total documents after removal are empty and no new files
      if (
        (!pdfFiles?.length || pdfFiles.length === 0) &&
        remainingDocs.length === 0
      ) {
        return res
          .status(400)
          .json({ message: "At least one file must be uploaded." });
      }

      // Validate file count
      if (allowMultiple && pdfFiles?.length > 5) {
        return res
          .status(400)
          .json({ message: "You can upload up to 5 files." });
      }

      if (!allowMultiple && pdfFiles?.length > 1) {
        return res
          .status(400)
          .json({ message: "Only one file allowed for this course." });
      }

      // Delete removed files from Cloudinary
      for (const publicId of removedFiles || []) {
        await deletePdfFromCloudinary(publicId);
      }

      // Upload new files
      for (const file of pdfFiles || []) {
        if (file.size > 1024 * 1024) {
          return res.status(400).json({
            message: `${file.originalname} exceeds 1MB file size limit.`,
          });
        }

        const { url, public_id } = await uploadPdfToCloudinary(
          file.buffer,
          studentProfile.name,
          studentProfile.bmdcNo
        );

        remainingDocs.push({
          url,
          public_id,
          name: file.originalname,
          size: file.size,
        });

        if (!allowMultiple) break; // stop if only one allowed
      }

      const updatedCourse = {
        _id: courseId,
        status: "yes",
        completionYear,
        documents: remainingDocs,
      };

      if (existingCourseIndex > -1) {
        studentProfile.courses[existingCourseIndex] = updatedCourse;
      } else {
        studentProfile.courses.push(updatedCourse);
      }

      await studentProfile.save();

      return res.status(200).json({
        message: "Course updated successfully.",
        studentProfile,
      });
    }

    return res.status(400).json({ message: "Invalid status value." });
  } catch (error) {
    console.error("Error updating course document:", error);
    return res.status(500).json({
      message: "Server error occurred while updating the course document.",
    });
  }
};

// ************************************************** Upload PDF & Update Status ****************************************** //

// ************************************************** Update Student Profile Data ************************************************** //
const updateStudentDetails = async (req, res) => {
  try {
    const studentId = req.user._id;
    let updateData = req.body;
    console.log("Request Body:", updateData);

    // Find the student by ID
    const student = await Student.findById(studentId);
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    // Validate and sanitize postGraduationDegrees[0]
    if (Array.isArray(updateData.postGraduationDegrees)) {
      const degree = updateData.postGraduationDegrees[0];

      if (degree?.isCompleted === true) {
        const cleanedDegreeName = degree.degreeName?.trim();
        const cleanedYearString = degree.yearOfGraduation?.replace(/\D/g, "");
        const year = Number(cleanedYearString);
        const currentYear = new Date().getFullYear();

        // Basic presence validation
        if (!cleanedDegreeName || !cleanedYearString) {
          return res.status(400).json({
            message:
              "To mark post graduation as complete, both 'Degree Name' and a valid 'Year of Post Graduation' are required.",
          });
        }

        // Year validation
        if (isNaN(year)) {
          return res.status(400).json({
            message: "Year of Post Graduation must be a valid number.",
          });
        }

        if (year < 1971) {
          return res.status(400).json({
            message: "'Year of Post Graduation' cannot be before 1971.",
          });
        }

        if (year > currentYear) {
          return res.status(400).json({
            message: `'Year of Post Graduation' cannot be later than ${currentYear}.`,
          });
        }

        // Update cleaned values
        degree.degreeName = cleanedDegreeName;
        degree.yearOfGraduation = String(year);
      } else {
        // If not completed, reset values
        degree.degreeName = "Not Yet";
        degree.yearOfGraduation = "Not Yet";
      }

      // Put back updated degree object
      updateData.postGraduationDegrees[0] = degree;
    }
    // Check for duplicate email (if email is being updated)
    if (updateData.email && updateData.email !== student.email) {
      const existingEmail = await Student.findOne({ email: updateData.email });
      if (existingEmail) {
        return res.status(400).json({ message: "Email is already in use." });
      }
    }

    // Check for duplicate BMDC number (if being updated)
    if (updateData.bmdcNo && updateData.bmdcNo !== student.bmdcNo) {
      const existingBmdc = await Student.findOne({ bmdcNo: updateData.bmdcNo });
      if (existingBmdc) {
        return res
          .status(400)
          .json({ message: "BMDC number is already in use." });
      }
    }

    // Check for duplicate contact number (if being updated)
    if (
      updateData.contactNumber &&
      updateData.contactNumber !== student.contactNumber
    ) {
      const existingContact = await Student.findOne({
        contactNumber: updateData.contactNumber,
      });
      if (existingContact) {
        return res
          .status(400)
          .json({ message: "Contact number is already in use." });
      }
    }

    // Prevent updates to `name` and `bmdcNo` if BMDC is verified
    if (student.isBmdcVerified) {
      delete updateData.name; // Prevent name change
      delete updateData.bmdcNo; // Prevent BMDC number change
    }

    // Update the student document with the allowed fields
    const updatedStudent = await Student.findByIdAndUpdate(
      studentId,
      updateData,
      { new: true }
    );

    res.status(200).json({
      message: "Student details updated successfully",
      student: updatedStudent,
    });
  } catch (error) {
    console.error("Error updating student details:", error);

    // Handle MongoDB duplicate key error
    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern)[0]; // Get the duplicate field
      return res.status(400).json({ message: `${field} is already in use.` });
    }

    res.status(500).json({
      message: "Error updating student details",
      error: error.message,
    });
  }
};

// ************************************************** Is AccountVerified Data list ************************************************** //
const getUnverifiedStudents = async (req, res) => {
  try {
    const unverifiedStudents = await Student.find({
      isAccountVerified: false,
      isEmailVerified: true,

      // Ensure currentWorkingPlace has at least one entry with both name and designation
      currentWorkingPlace: {
        $elemMatch: {
          name: { $nin: [null, "", "N/A"] },
          designation: { $nin: [null, "", "N/A"] },
        },
      },

      // Ensure postGraduationDegrees has at least one entry with degreeName and yearOfGraduation
      postGraduationDegrees: {
        $elemMatch: {
          degreeName: { $ne: null, $ne: "" },
          yearOfGraduation: { $ne: null },
        },
      },

      // Ensure picture array is not empty and contains at least one with url and public_id
      picture: {
        $elemMatch: {
          url: { $ne: null, $ne: "" },
          public_id: { $ne: null, $ne: "" },
        },
      },
    });
    res.json(unverifiedStudents);
  } catch (error) {
    console.error("Error fetching unverified students:", error);
    res.status(500).json({ message: "Error fetching unverified students." });
  }
};
// ************************************************** Controller for Verified Student Data start here ************************************************** //

const getVerifiedStudents = async (req, res) => {
  try {
    const { search, yearFrom, yearTo, courses } = req.query;

    const query = {
      isAccountVerified: true,
    };

    // Search filter (name, email, bmdcNo, contactNumber)
    if (search) {
      const regex = new RegExp(search, "i");
      const orConditions = [
        { name: { $regex: regex } },
        { email: { $regex: regex } },
        {
          $expr: {
            $regexMatch: {
              input: { $toString: "$bmdcNo" },
              regex: regex,
            },
          },
        },
        {
          $expr: {
            $regexMatch: {
              input: { $toString: "$contactNumber" },
              regex: regex,
            },
          },
        },
      ];
      query.$or = orConditions;
    }

    // Year filter on postGraduationDegrees.yearOfGraduation
    if (yearFrom || yearTo) {
      query.postGraduationDegrees = {
        $elemMatch: { isCompleted: true },
      };
      if (yearFrom) {
        query.postGraduationDegrees.$elemMatch.yearOfGraduation = {
          ...(query.postGraduationDegrees.$elemMatch.yearOfGraduation || {}),
          $gte: yearFrom.toString(),
        };
      }

      if (yearTo) {
        query.postGraduationDegrees.$elemMatch.yearOfGraduation = {
          ...(query.postGraduationDegrees.$elemMatch.yearOfGraduation || {}),
          $lte: yearTo.toString(),
        };
      }
    }

    // Courses filter
    if (courses) {
      const courseArray = Array.isArray(courses)
        ? courses
        : courses.split(",").map((id) => id.trim());
      console.log(courseArray, "This is the course array");

      // Build an array of $elemMatch conditions for each course
      const courseConditions = courseArray.map((id) => ({
        courses: {
          $elemMatch: {
            _id: id, // MongoDB can match string _id
            status: "yes",
          },
        },
      }));

      // Add all courseConditions to the query using $and
      if (courseConditions.length > 0) {
        query.$and = [...(query.$and || []), ...courseConditions];
      }
    }

    console.log("Final Query:", JSON.stringify(query, null, 2));

    const includeExtraFields = yearFrom || yearTo || courses;

const projection = includeExtraFields
  ? undefined
  : "name bmdcNo email contactNumber aoaNo";

const verifiedStudents = await Student.find(query).select(projection).lean();

    // Return the results
    res.status(200).json(verifiedStudents);
  } catch (error) {
    console.error("Error fetching verified students:", error);
    res.status(500).json({ message: "Error fetching verified students" });
  }
};

// ************************************************** Controller for Verified Student Data End here ************************************************** //


// ************************************************** Controller for approve student ************************************************** //

const approveStudent = async (req, res) => {
  const { studentId } = req.params;

  try {
    const student = await Student.findById(studentId);

    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    // Set verification fields
    student.isAccountVerified = true;
    student.isBmdcVerified = true;
    student.remarks = null;

    // Set aoaNo only if not already set
    if (!student.aoaNo && student.bmdcNo) {
      student.aoaNo = `AOA-${student.bmdcNo}`;
    }

    await student.save();

    console.log("Student Approved:", student);
    res.json(student);
  } catch (error) {
    console.error("Error approving student:", error);
    res.status(500).json({ message: "Error approving student" });
  }
};
// ************************************************** Controller for approve student End Here************************************************** //


// ************************************************** Controller for deny student Start Here************************************************** //
const denyStudent = async (req, res) => {
  const { studentId } = req.params;
  const { remarks } = req.body;
  console.log(studentId);
  console.log(remarks);

  // Validate that remarks are provided
  if (!remarks || remarks.trim() === "") {
    return res.status(400).json({ message: "Remarks are required" });
  }

  try {
    const updatedStudent = await Student.findByIdAndUpdate(
      studentId,
      {
        isAccountVerified: false,
        isBmdcVerified: null,
        remarks,
      },
      { new: true } // Return the updated document
    );

    if (!updatedStudent) {
      return res.status(404).json({ message: "Student not found" });
    }

    console.log("Student Denied:", updatedStudent);
    res.json(updatedStudent);
  } catch (error) {
    console.error("Error denying student:", error);
    res.status(500).json({ message: "Error denying student" });
  }
};

// ************************************************** Controller for deny student End Here************************************************** //


// ************************************************** Controller for Summary Start Here************************************************** //

const getAllStudentStatusSummary = async (req, res) => {
  try {
    // Step 1: Aggregate counts for approved, wrong entry, total
    const result = await Student.aggregate([
      {
        $facet: {
          total: [{ $count: "count" }],
          approved: [
            { $match: { isAccountVerified: true } },
            { $count: "count" },
          ],
          wrongEntry: [
            { $match: { isEmailVerified: false } },
            { $count: "count" },
          ],
        },
      },
    ]);

    const formatCount = (arr) => (arr[0] ? arr[0].count : 0);

    const data = result[0];
    const total = formatCount(data.total);
    const approved = formatCount(data.approved);
    const wrongEntry = formatCount(data.wrongEntry);

    // Step 2: Get pending count using your existing pending logic
    const pendingStudents = await Student.find({
      isAccountVerified: false,
      isEmailVerified: true,
      currentWorkingPlace: {
        $elemMatch: {
          name: { $nin: [null, "", "N/A"] },
          designation: { $nin: [null, "", "N/A"] },
        },
      },
      postGraduationDegrees: {
        $elemMatch: {
          degreeName: { $ne: null, $ne: "" },
          yearOfGraduation: { $ne: null },
        },
      },
      picture: {
        $elemMatch: {
          url: { $ne: null, $ne: "" },
          public_id: { $ne: null, $ne: "" },
        },
      },
    });

    const pending = pendingStudents.length;

    // Step 3: Derive incomplete accounts
    const accountNotComplete = total - (approved + wrongEntry + pending);

    // Step 4: Respond
    res.json({
      summary: {
        total,
        approved,
        wrongEntry,
        pending,
        accountNotComplete,
      },
    });
  } catch (error) {
    console.error("Error in getAllStudentStatusSummary:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

// ************************************************** Controller for Summary End Here************************************************** //


// ************************************************** Controller for Unverified email address controller Start Here************************************************** //

const getUnverifiedEmail = async (req, res) => {
  try {
    const unverifiedStudents = await Student.find(
      { isEmailVerified: false } // Filter condition
    ).sort({ createdAt: 1 }); // Optional: sort by creation date (oldest first)
    res.status(200).json(unverifiedStudents);
  } catch (error) {
    console.error("Error fetching unverified students:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// remove uinverified acconunt
const removeUnverifiedEmailById = async (req, res) => {
  try {
    const { id } = req.params;

    // Find the student first
    const student = await Student.findById(id);

    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    if (student.isEmailVerified) {
      return res
        .status(400)
        .json({ message: "Student email is already verified. Cannot delete." });
    }

    // Delete if not verified
    await Student.findByIdAndDelete(id);

    res
      .status(200)
      .json({ message: "Unverified student account deleted successfully" });
  } catch (error) {
    console.error("Error deleting student:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// ************************************************** Controller for Unverified email address controller End Here************************************************** //

module.exports = {
  getProfileData,
  updateProfileImage,
  updateCourseDocument,
  updateStudentDetails,
  getUnverifiedStudents,
  approveStudent,
  getVerifiedStudents,
  denyStudent,
  getStudentProfileByAdmin,
  getAllStudentStatusSummary,
  getUnverifiedEmail,
  removeUnverifiedEmailById,
};
